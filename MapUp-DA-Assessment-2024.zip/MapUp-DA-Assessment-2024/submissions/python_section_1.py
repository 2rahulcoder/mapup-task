from typing import Dict, List

import pandas as pd
import numpy as np 
import re
import polyline


def reverse_by_n_elements(lst: List[int], n: int) -> List[int]:
    """
    <DONE 1>
    
    Reverses the input list by groups of n elements.
    """
    # Your code goes here.
    """
    Reverses the input list by groups of n elements.
    
    :param lst: List of integers to be reversed in groups
    :param n: The number of elements in each group to be reversed
    :return: A modified list where each group of n elements is reversed
    """
    length = len(lst)  # Get the length of the input list
    
    for i in range(0, length, n):  # Iterate over the list in steps of n
        # Reverse the current group manually
        left = i
        right = min(i + n - 1, length - 1)
        
        while left < right:
            # Swap the elements
            lst[left], lst[right] = lst[right], lst[left]
            left += 1
            right -= 1

    return lst


def group_by_length(lst: List[str]) -> Dict[int, List[str]]:
    """
    <DONE 2>
    Groups the strings by their length and returns a dictionary.

    :param lst: List of strings to be grouped by length
    :return: A dictionary where keys are string lengths and values are lists of strings of that length
    """
    length_dict = {}  # Initialize an empty dictionary

    for string in lst:  # Iterate through each string in the list
        length = len(string)  # Get the length of the string
        
        if length not in length_dict:  # If length is not a key in the dictionary, add it
            length_dict[length] = []
        
        length_dict[length].append(string)  # Append the string to the corresponding length key

    # Sort the dictionary by keys (lengths) and return as a new dictionary
    return dict(sorted(length_dict.items()))



def flatten_dict(nested_dict: Dict, sep: str = '.') -> Dict:
    """
    <DONE 3>
    Flattens a nested dictionary into a single-level dictionary with dot notation for keys.
    
    :param nested_dict: The dictionary object to flatten
    :param sep: The separator to use between parent and child keys (defaults to '.')
    :return: A flattened dictionary
    """
    flat_dict = {}

    def flatten(current_dict, parent_key=''):
        for key, value in current_dict.items():
            new_key = f"{parent_key}{sep}{key}" if parent_key else key
            if isinstance(value, dict):
                flatten(value, new_key)
            elif isinstance(value, list):
                for i, item in enumerate(value):
                    flatten({f"{new_key}[{i}]": item})  # Flatten list elements
            else:
                flat_dict[new_key] = value

    flatten(nested_dict)
    return flat_dict



def unique_permutations(nums: List[int]) -> List[List[int]]:
    """
    <DONE 4>
    Generate all unique permutations of a list that may contain duplicates.
    
    :param nums: List of integers (may contain duplicates)
    :return: List of unique permutations
    """
    def backtrack(start=0):
        if start == len(nums):
            result.append(nums[:])  # Make a copy of the current permutation
            return
        seen = set()  # Track seen numbers to avoid duplicates
        for i in range(start, len(nums)):
            if nums[i] not in seen:  # Check if this number has been used in this position
                seen.add(nums[i])
                nums[start], nums[i] = nums[i], nums[start]  # Swap to create new permutation
                backtrack(start + 1)  # Recur
                nums[start], nums[i] = nums[i], nums[start]  # Backtrack

    result = []
    nums.sort()  # Sort to ensure duplicates are adjacent
    backtrack()
    return result


def find_all_dates(text: str) -> List[str]:
    """
    <DONE 5>
    This function takes a string as input and returns a list of valid dates
    in 'dd-mm-yyyy', 'mm/dd/yyyy', or 'yyyy.mm.dd' format found in the string.
    
    Parameters:
    text (str): A string containing the dates in various formats.

    Returns:
    List[str]: A list of valid dates in the formats specified.
    """
    # Regular expression pattern for matching the specified date formats
    pattern = r'(?:(\d{2})-(\d{2})-(\d{4}))|(?:(\d{2})/(\d{2})/(\d{4}))|(?:(\d{4})\.(\d{2})\.(\d{2}))'
    
    # Find all matches in the text
    matches = re.findall(pattern, text)
    
    # Extract valid dates from the matches
    valid_dates = []
    for match in matches:
        if match[0]:  # dd-mm-yyyy format
            valid_dates.append(f"{match[0]}-{match[1]}-{match[2]}")
        elif match[3]:  # mm/dd/yyyy format
            valid_dates.append(f"{match[3]}/{match[4]}/{match[5]}")
        elif match[6]:  # yyyy.mm.dd format
            valid_dates.append(f"{match[6]}.{match[7]}.{match[8]}")

    return valid_dates

def haversine(coord1, coord2):
    """
    <DONE 6>
    Calculate the great-circle distance between two points on the Earth specified in decimal degrees
    using the Haversine formula.

    Args:
        coord1 (tuple): A tuple (latitude, longitude) for the first point.
        coord2 (tuple): A tuple (latitude, longitude) for the second point.

    Returns:
        float: Distance in meters between the two points.
    """
    # Convert latitude and longitude from degrees to radians
    lat1, lon1 = np.radians(coord1)
    lat2, lon2 = np.radians(coord2)

    # Haversine formula
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = np.sin(dlat / 2)**2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2)**2
    c = 2 * np.arctan2(np.sqrt(a), np.sqrt(1 - a))

    # Radius of Earth in meters
    radius = 6371000  
    return radius * c

def polyline_to_dataframe(polyline_str: str) -> pd.DataFrame:
    """
    <DONE 6>
    Converts a polyline string into a DataFrame with latitude, longitude, and distance between consecutive points.
    
    Args:
        polyline_str (str): The encoded polyline string.

    Returns:
        pd.DataFrame: A DataFrame containing latitude, longitude, and distance in meters.
    """
    # Decode the polyline string to get coordinates
    decoded_coordinates = polyline.decode(polyline_str)

    # Create a DataFrame with the decoded coordinates
    df = pd.DataFrame(decoded_coordinates, columns=['latitude', 'longitude'])

    # Calculate distances between consecutive points
    distances = [0]  # First point has distance 0
    for i in range(1, len(decoded_coordinates)):
        distance = haversine(decoded_coordinates[i-1], decoded_coordinates[i])
        distances.append(distance)

    # Add distances to the DataFrame
    df['distance'] = distances

    return df  # Return the DataFrame containing the coordinates and distances




def rotate_and_multiply_matrix(matrix: List[List[int]]) -> List[List[int]]:
    """
    <DONE 7>
    Rotate the given matrix by 90 degrees clockwise, then replace each element 
    with the sum of all elements in the same row and column, excluding itself.
    
    Args:
    - matrix (List[List[int]]): 2D list representing the matrix to be transformed.
    
    Returns:
    - List[List[int]]: A new 2D list representing the transformed matrix.
    """
    n = len(matrix)
    
    # Step 1: Rotate the matrix by 90 degrees clockwise
    rotated_matrix = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            rotated_matrix[j][n - 1 - i] = matrix[i][j]

    # Step 2: Transform the rotated matrix
    final_matrix = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            row_sum = sum(rotated_matrix[i])  # Sum of the row
            col_sum = sum(rotated_matrix[k][j] for k in range(n))  # Sum of the column
            final_matrix[i][j] = row_sum + col_sum - rotated_matrix[i][j]  # Exclude itself

    return final_matrix


def time_check(df: pd.DataFrame) -> pd.Series:
    """
    <DONE 8>
    Verify the completeness of the data by checking whether the timestamps for each unique (`id`, `id_2`) pair cover
    a full 24-hour and 7 days period.

    Args:
        df (pandas.DataFrame): DataFrame containing the time data.

    Returns:
        pd.Series: A boolean series indicating if each (`id`, `id_2`) pair has incorrect timestamps.
    """
    # Convert the timestamp columns to datetime
    df['start'] = pd.to_datetime(df['startDay'] + ' ' + df['startTime'])
    df['end'] = pd.to_datetime(df['endDay'] + ' ' + df['endTime'])

    # Define a function to check the timestamps for each group
    def check_time(group):
        # Create a complete range of dates (Monday to Sunday)
        full_week = pd.date_range(start=group['start'].min().floor('D'), 
                                   end=group['end'].max().ceil('D'), 
                                   freq='D')
        
        # Check if the group spans all 7 days
        days_covered = group['start'].dt.dayofweek.unique()
        spans_all_days = len(days_covered) == 7

        # Check if the group covers a full 24-hour period
        starts_24_hours = (group['start'].min().floor('D') == group['end'].max().floor('D')) and \
                          (group['start'].min() <= group['end'].max())

        return not (spans_all_days and starts_24_hours)

    # Group by ('id', 'id_2') and apply the check_time function
    result = df.groupby(['id', 'id_2']).apply(check_time)

    # Convert the result to a boolean pd.Series
    return pd.Series(result)

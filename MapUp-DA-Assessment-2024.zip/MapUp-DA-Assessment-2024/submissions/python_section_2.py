import pandas as pd
from datetime import time


def calculate_distance_matrix(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate a distance matrix based on the dataframe, df.

    Args:
        df (pandas.DataFrame): DataFrame containing columns 'from_id', 'to_id', and 'distance'.

    Returns:
        pandas.DataFrame: Distance matrix with cumulative distances.
    """
    # Create a unique list of IDs
    unique_ids = pd.concat([df['from_id'], df['to_id']]).unique()
    
    # Initialize the distance matrix with zeros
    distance_matrix = pd.DataFrame(0, index=unique_ids, columns=unique_ids)

    # Fill the distance matrix with the given distances
    for _, row in df.iterrows():
        from_id = row['from_id']
        to_id = row['to_id']
        distance = row['distance']
        
        # Set the distances for both directions
        distance_matrix.at[from_id, to_id] = distance
        distance_matrix.at[to_id, from_id] = distance

    # Calculate cumulative distances using the Floyd-Warshall algorithm
    for k in unique_ids:
        for i in unique_ids:
            for j in unique_ids:
                # If there's already a direct distance, skip it
                if distance_matrix.at[i, j] > 0:
                    continue
                new_distance = distance_matrix.at[i, k] + distance_matrix.at[k, j]
                if new_distance > 0:
                    distance_matrix.at[i, j] = new_distance

    return df  


def unroll_distance_matrix(df: pd.DataFrame) -> pd.DataFrame:
    """
    Unroll a distance matrix into a DataFrame in long format.

    Args:
        df (pandas.DataFrame): A square DataFrame where the index and columns represent location IDs, 
                               and values represent distances.

    Returns:
        pandas.DataFrame: A DataFrame with columns 'id_start', 'id_end', and 'distance', 
                          representing distances between locations.
    """
    unrolled_data = []
    
    # Iterate through the DataFrame to extract non-diagonal values
    for id_start in df.index:
        for id_end in df.columns:
            if id_start != id_end:  # Skip diagonal values
                unrolled_data.append({
                    'id_start': id_start,
                    'id_end': id_end,
                    'distance': df.loc[id_start, id_end]
                })
    
    # Create the unrolled DataFrame
    unrolled_df = pd.DataFrame(unrolled_data)
    
    return unrolled_df


def find_ids_within_ten_percentage_threshold(df: pd.DataFrame, reference_id: int) -> list:
    """
    Find all IDs whose average distance lies within 10% of the average distance of the reference ID.

    Args:
        df (pandas.DataFrame): DataFrame containing 'id_start', 'id_end', and 'distance' columns.
        reference_id (int): The reference ID to compare other IDs against.

    Returns:
        list: Sorted list of `id_start` values whose average distance is within the specified percentage threshold.
    """
    # Step 1: Calculate the average distance for the reference ID
    ref_avg_distance = df[df['id_start'] == reference_id]['distance'].mean()
    
    # Step 2: Define the 10% threshold range
    lower_threshold = ref_avg_distance * 0.9
    upper_threshold = ref_avg_distance * 1.1
    
    # Step 3: Calculate the average distance for each 'id_start'
    avg_distances = df.groupby('id_start')['distance'].mean().reset_index()
    avg_distances.columns = ['id_start', 'avg_distance']
    
    # Step 4: Filter the IDs whose average distance falls within the 10% threshold
    filtered_ids = avg_distances[
        (avg_distances['avg_distance'] >= lower_threshold) &
        (avg_distances['avg_distance'] <= upper_threshold)
    ]['id_start']
    
    # Step 5: Return the sorted list of IDs
    return sorted(filtered_ids)


def calculate_toll_rate(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate toll rates for each vehicle type based on the unrolled DataFrame.

    Args:
        df (pandas.DataFrame): DataFrame containing 'id_start', 'id_end', and 'distance' columns.

    Returns:
        pandas.DataFrame: DataFrame with additional columns for toll rates: 'moto', 'car', 'rv', 'bus', 'truck'.
    """
    # Step 1: Define the toll rate coefficients for each vehicle type
    rate_coefficients = {
        'moto': 0.8,
        'car': 1.2,
        'rv': 1.5,
        'bus': 2.2,
        'truck': 3.6
    }
    
    # Step 2: Add new columns for each vehicle type by multiplying the distance with the respective rate coefficient
    df['moto'] = df['distance'] * rate_coefficients['moto']
    df['car'] = df['distance'] * rate_coefficients['car']
    df['rv'] = df['distance'] * rate_coefficients['rv']
    df['bus'] = df['distance'] * rate_coefficients['bus']
    df['truck'] = df['distance'] * rate_coefficients['truck']
    
    # Step 3: Return the updated DataFrame
    return df


def calculate_time_based_toll_rates(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate time-based toll rates for different time intervals within a day.

    Args:
        df (pandas.DataFrame): DataFrame containing toll rates for different vehicles.
    
    Returns:
        pandas.DataFrame: DataFrame with time-based toll rates and added time interval columns.
    """
    # Define days of the week
    weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
    weekends = ['Saturday', 'Sunday']
    
    # Define time intervals
    time_intervals = [
        (time(0, 0), time(10, 0)),  # 00:00:00 - 10:00:00
        (time(10, 0), time(18, 0)),  # 10:00:00 - 18:00:00
        (time(18, 0), time(23, 59, 59))  # 18:00:00 - 23:59:59
    ]
    
    # Discount factors
    discount_factors_weekday = [0.8, 1.2, 0.8]
    discount_factor_weekend = 0.7
    
    # List to store result
    result = []
    
    # Iterate through each combination of id_start and id_end
    for _, row in df.iterrows():
        for day in weekdays + weekends:
            for (start_time, end_time), discount_factor in zip(time_intervals, discount_factors_weekday):
                # Check if it's a weekend, apply weekend factor
                if day in weekends:
                    discount_factor = discount_factor_weekend
                
                # Adjust toll rates based on the discount factor
                result.append({
                    'id_start': row['id_start'],
                    'id_end': row['id_end'],
                    'distance': row['distance'],
                    'start_day': day,
                    'start_time': start_time,
                    'end_day': day,
                    'end_time': end_time,
                    'moto': row['moto'] * discount_factor,
                    'car': row['car'] * discount_factor,
                    'rv': row['rv'] * discount_factor,
                    'bus': row['bus'] * discount_factor,
                    'truck': row['truck'] * discount_factor
                })
    
    # Create a DataFrame from the result list
    result_df = pd.DataFrame(result)
    
    return result_df
